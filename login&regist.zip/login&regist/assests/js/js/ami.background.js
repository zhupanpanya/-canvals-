
var ami = (function() {
	var context = null, 								// context
		pointArr = [], 									// 存放所有模拟小球的对象数组
		screenWidth = 0, 								// 屏幕宽度
		screenHeight = 0, 								// 屏幕高度
		point = 0; 										// 小球个数
	/**
	 *
	 线条类
	 *
	 @class Line
	 *
	 @constructor
	 * 
	 @property {Number} [startX] 开始x坐标
	 * 
	 @property {Number} [startY] 开始y坐标
	 * 
	 @property {Number} [endX] 结束x坐标
	 * 
	 @property {Number} [endY] 结束y坐标
	 * 
	 @property {Number} [opacity] 透明度
	 */
	function Line(startX, startY, endX, endY, opacity) {
		this.startX = startX;							// 开始x坐标
		this.startY = startY;							// 开始y坐标
		this.endX = endX;								// 结束x坐标
		this.endY = endY;								// 结束y坐标
		this.opacity = opacity;							// 透明度
	}
	/**
	 *
	 圆（小球）类
	 *
	 @class Circle
	 *
	 @constructor
	 * 
	 @property {Number} [originX] 原点x坐标
	 * 
	 @property {Number} [originY] 原点y坐标
	 * 
	 @property {Number} [originR] 半径
	 * 
	 @property {Number} [originRC] 颜色RGB中的R
	 * 
	 @property {Number} [originGC] 颜色RGB中的G
	 *
	 @property {Number} [originBC] 颜色RGB中的B
	 *
	 @property {Number} [moveX] x轴移动距离
	 *
	 @property {Number} [moveY] y轴移动距离
	 */
	function Circle(originX, originY, originR, originRC, originGC, originBC, moveX, moveY) {
		this.originX = originX;							// 原点x坐标
		this.originY = originY;							// 原点y坐标
		this.originR = originR;							// 半径
		this.originRC = originRC;						// 颜色RGB,R通道
		this.originGC = originGC;						// 颜色RGB,G通道
		this.originBC = originBC;						// 颜色RGB,B通道
		this.moveX = moveX;								// x轴移动距离
		this.moveY = moveY;								// y轴移动距离
	}
	/**
	 *
	 包含本功能所有方法的对象
	 *
	 */
	var methods = {

		move: function() {
			for(var i = 0; i < point; i++) {
				var oneCircle = pointArr[i];
				oneCircle.originX += oneCircle.moveX;
				oneCircle.originY += oneCircle.moveY;
				if(oneCircle.originX > screenWidth) {
					oneCircle.originX = oneCircle.originR;
				} else if(oneCircle.originX < 0) {
					oneCircle.originX = screenWidth-oneCircle.originR;
				}
				if(oneCircle.originY > screenHeight) {
					oneCircle.originY = oneCircle.originR;
				} else if(oneCircle.originY < 0) {
					oneCircle.originY = screenHeight-oneCircle.originR;
				}
			}
			methods.frameDraw();
		},
		/**
		 *
		 1. 此方法当运行本插件后立即运行，是整个功能的入口，其中methods.init方法用于
		 初始设置一些基本所需的东西，如屏幕宽/高，小球个数，canvas的宽/高，context
		 对象，并画出整个界面，包括随机生成的小球和线条，只是不会动而已
		 2. 此方法第二个作用即是使用一个定时器函数来调用上面的methods.move方法来生成
		 最终的动画
		 *
		 @method  run
		 *
		 @for ami 属于本类顶级函数
		 *
		 @param {Object} [options] 这个参数是从前端页面传来的，包括要在那个canvas上画图的"canvasDiv"及
		 要生成多少个小球的"point"，其中canvasDiv是一个字符串，point则是一个整型数字
		 */
		run: function(options) {
			methods.init(options);
			var ints = setInterval(methods.move, 1);
		},
	
		renderCanvas: function() {
			pointArr = [];
			for(var i = 0; i < point; i++) {
				var circle = methods.drawCircle(context, methods.rand(screenWidth), methods.rand(screenHeight), methods.rand(10, 2), methods.rand(255, 0), methods.rand(255, 0), methods.rand(255, 0), methods.rand(10, -10) / 40, methods.rand(10, -10) / 40)
				pointArr.push(circle);
			}
			methods.frameDraw();
		},

		init: function(options) {
			var width = window.innerWidth,
				height = window.innerHeight;
			var canvas = document.getElementById(options.canvasDiv);
			canvas.width = width;
			canvas.height = height;
			context = canvas.getContext('2d');
			screenWidth = width;
			screenHeight = height;
			point = (typeof options.point == 'undefined' || typeof options.point != 'number') ? 35 : options.point;
			methods.renderCanvas();
		},
		/**
		 *
		 生成两个数之间的一位随机数，注意里面的arguments是js中提供的，它是一个类数组，下标从0开始，里面存放的
		 是传入该函数的所有参数，arguments[1]就是min参数，我们先定义一个临时变量mins，如果只传一个参数mins就
		 是0，如果传2个参数，mins就是第二个参数的值，即arguments[1]
		 *
		 @method  rand
		 *
		 @for ami 属于本类顶级函数
		 *
		 @param {Number} [max] 最大数
		 *
		 @param {Number} [min] 最小数
		 */
		rand: function(max, min) {
			var mins = arguments[1] || 0;
			return Math.floor(Math.random() * (max - mins + 1) + mins);
		},
		
		drawCircle: function(context, originX, originY, originR, originRC, originGC, originBC, moveX, moveY) {
			var circle = new Circle(originX, originY, originR, originRC, originGC, originBC, moveX, moveY);
			context.beginPath();
			context.strokeWidth = 1;
			context.fillStyle = 'rgba(' + circle.originRC + ',' + originGC + ',' + originBC + ',1)';
			context.arc(circle.originX, circle.originY, circle.originR, 0, 2 * Math.PI);
			context.closePath();
			context.fill();
			return circle;
		},
		
		drawLine: function(context, startX, startY, endX, endY, opacity) {
			var line = new Line(startX, startY, endX, endY, opacity);
			context.beginPath();
			context.strokeStyle = 'rgba(0,137,183,' + opacity + ')';
			context.moveTo(line.startX, line.startY)
			context.lineTo(line.endX, line.endY)
			context.closePath()
			context.stroke();
		},
	
		frameDraw: function() {
			context.clearRect(0, 0, screenWidth, screenHeight);
			for(var i = 0; i < point; i++) {
				methods.drawCircle(context, pointArr[i].originX, pointArr[i].originY, pointArr[i].originR, pointArr[i].originRC, pointArr[i].originGC, pointArr[i].originBC);
			}
			for(var i = 0; i < point; i++) {
				for(var j = 1; j < point; j++) {
					if(i + j < point) {
						var sqrtA = Math.abs(pointArr[i + j].originX - pointArr[i].originX),
							sqrtB = Math.abs(pointArr[i + j].originY - pointArr[i].originY);
						var lineLength = Math.sqrt(sqrtA * sqrtA + sqrtB * sqrtB);
						var C = 4 / lineLength * 7 - 0.009;
						var lineOpacity = C > 0.6 ? 0.6 : C;
						if(lineOpacity > 0) {
							methods.drawLine(context, pointArr[i].originX, pointArr[i].originY, pointArr[i + j].originX, pointArr[i + j].originY, lineOpacity);
						}
					}
				}
			}
		}
	}
	return function(obj) {
		return methods.run(obj);
	}
})();