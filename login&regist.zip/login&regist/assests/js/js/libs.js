
;var sL = (function($) {
	return {
		
		getSingle: function(fn) {
			var result;
			return function() {
				return result || (result = fn.apply(this, arguments));
			}
		},
		
		setCenter: function(elem) {
			var screenWidth = $(window).width(),
				screenHeight = $(window).height(), //当前浏览器窗口的宽高
				scrollTop = $(document).scrollTop(), //获取当前窗口距离页面顶部高度
				elemLeft = (screenWidth - elem.width()) / 2,
				elemTop = (screenHeight - elem.height()) / 2 + scrollTop-80;
			elem.css({
				left: elemLeft + 'px',
				top: elemTop + 'px'
			});
			var setDy = function(){
				screenWidth = $(window).width();
				screenHeight = $(window).height();
				scrollTop = $(document).scrollTop();
				elemLeft = (screenWidth - elem.width()) / 2;
				elemTop = (screenHeight - elem.height()) / 2 + scrollTop-80;
				elem.animate({
					left: elemLeft + 'px',
					top: elemTop + 'px'
				},150,function(){});
			}
			$(window).resize(function() {
				setDy();
			});
			$(window).scroll(function() {
				setDy();
			});
		}
	}
})(jQuery);