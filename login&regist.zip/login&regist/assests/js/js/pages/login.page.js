$(function() {
	var myLib = sL,
		myAmi = ami,
		loginDiv = $('#j-login');
	myLib.setCenter(loginDiv);
	myAmi({
		canvasDiv: 'j-canvas',
		point: 35
	});
	//登录
	var timer;
	//倒计时start
	var curTime = 0,
		timer = null,
		btn = $('#verCode');

	function handleTimer() {
		if(curTime == 0) {
			clearInterval(timer);
			timer = null;
			$("#verCode").css("color", "#36518D");
			btn.text('重新发送');
		} else {
			$("#verCode").css("color", "#ccc");
			btn.text(curTime + 's后发送');
			curTime--;
		}
	}


	function verification() {};
	//手机号
	verification.prototype.phone = function(value, errormsg, dom) {
			var check;
			$(".error").remove();
			var values = value.val();
			if(!(/^1[3|4|5|7|8][0-9]\d{4,8}$/.test(values))) {
				dom.after($("<span>").addClass("error").append(errormsg).fadeIn("fast"));
				//.delay(1000).fadeOut("fast"));
				check = false;
				value.focus();
			} else {
				check = true;
			}
			return check;
		}
		//验证码
	verification.prototype.yanzheng = function(value, errormsg, dom) {
			var check;
			$(".error").remove();
			var values = value.val();
			if($.trim(values.length) <= 0) {
				dom.after($("<span>").addClass("error").append(errormsg).fadeIn("fast").delay(1000));
				$(".error").css("right","1.2rem");
				check = false;
				value.focus();
			} else {
				check = true;

			}
			return check;
		}
		//密码
	verification.prototype.password = function(value, errormsg, dom) {
			var check;
			$(".error").remove();
			var values = value.val();
			if(!(/^.*(?=.{6,})(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*? ]).*$/.test(values))) {
				dom.after($("<span>").addClass("error").append(errormsg).fadeIn("fast").delay(1000));
				check = false;
				value.focus();
			} else {
				check = true;

			}
			return check;
		}
		//密码确认
	verification.prototype.passwordAgain = function(password, value, errormsg, dom) {
		var check;
		$(".error").remove();
		var values = value.val();
		if(values != password) {
			dom.after($("<span>").addClass("error").append(errormsg).fadeIn("fast").delay(1000));
			check = false;
			value.focus();
		} else {
			check = true;

		}
		return check;
	}
	btn.on('click', function() {
		if(timer === null) {
			if(verifications.phone($("#phone"), "手机格式不正确", $("#phone"))) {
				curTime = 60;
				timer = setInterval(handleTimer, 1000);
			}else{
				verifications.phone($("#phone"), "手机格式不正确", $("#phone"))
				console.log(11)
			}

		}
	});
	var verifications = new verification();
		btn.on('click', function() {
		if(timer === null) {
			if(verifications.phone($("#phone"), "手机格式不正确", $("#phone"))) {
				curTime = 60;
				timer = setInterval(handleTimer, 1000);
			}
		}
	});
	$("body").delegate("#phone", "change", function() {
		verifications.phone($("#phone"), "手机格式不正确", $("#phone"));
	})

	$("body").delegate("#password", "change", function() {
		verifications.phone($("#password"), "密码格式不正确", $("#password"));
	})
	$("body").delegate("#passwordAgain", "change", function() {
		verifications.passwordAgain($("#passwordAgain"), "两次密码不一致", $("#passwordAgain"));
	})
	$("body").delegate("#code", "change", function() {
		verifications.yanzheng($("#code"), "验证码不能为空", $("#code"));
	})
	$("body").delegate("#code1", "change", function() {
		verifications.yanzheng($("#code1"), "验证码不能为空", $("#code1"));
	})
	
	//注册
	$("#regist").click(function() {
		var check = verifications.phone($("#phone"), "手机格式不正确", $("#phone")) && 
		verifications.yanzheng($("#code1"), "验证码不能为空", $("#code1"))&&
		verifications.yanzheng($("#code"), "验证码不能为空", $("#code"))&&
		verifications.phone($("#password"), "密码格式不正确", $("#password")) &&
		verifications.passwordAgain($("#passwordAgain"), "两次密码不一致", $("#passwordAgain"));
		if(check == false) {
			return check;
		}

	})
	//登录
	$("#logins").click(function() {
		var check = verifications.phone($("#phone"), "手机格式不正确", $("#phone")) && 
		verifications.phone($("#password"), "密码格式不正确", $("#password"))&&
		verifications.yanzheng($("#code1"), "验证码不能为空", $("#code1"));
		if(check == false) {
			return check;
		}
	})

});